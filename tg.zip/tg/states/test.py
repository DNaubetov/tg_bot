from aiogram.dispatcher.filters.state import StatesGroup, State


class Test(StatesGroup):
    Q1 = State()
    E1 = State()
    E2 = State()
    E3 = State()


