from .start import dp
from .menu import dp
from .contract import dp
from .time_table import dp
from .free_lessons import dp
from .sending_messages import dp
from .echo import dp
__all__ = ["dp"]
