BOT_TOKEN = "1234217208:AAGrfatqqSOuA56GCAs_v_60Je5WFr7fBkU"  # Your token
admin_id=330102092
URL_GROUP='https://t.me/joinchat/E6z1TBSQkgMCWkPBJ2aX-g'
URL_CHANNEL='https://t.me/oqiwlardinsultani'
URL_CONTRACT='https://forms.gle/5NLUmwcPLJsK3E7k7'